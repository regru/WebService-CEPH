package SRS::Comm::CEPH;

=encoding utf-8

=head1 NAME

SRS::Comm::CEPH

=head1 unicode ok

ok

=head1 DESCRIPTION

Клиент CEPH


=cut

use SRS::Perl;

use Sys::Hostname qw( hostname );
use Time::HiRes qw/gettimeofday usleep/;
use Carp;
use Sub::Name;

use SRS::Config;

use Redis::Fast 0.18;
use Exporter qw( import );

use parent qw( -norequire Redis::Fast );

use constant {
    RECONNECT                   => 20,
    EVERY                       => 100,
    CNX_TIMEOUT                 => 1,
    READ_TIMEOUT                => 10,
    WRITE_TIMEOUT               => 10,
    SCAN_BLOCK_SIZE             => 10_000,
    MICROSECONDS_IN_SECOND      => 1_000_000,
    CACHE_SERVER_DELTA          => 60,
    MAX_BLOCKING_SERVER_TIMEOUT => 60,
    FORCE_BLOCKING_TIMEOUTS     => [ qw/ fastqueue / ],
};


=item B<DEFAULT_CONNECT>

Список соединений, для которых будет созданы экспортируемые функции r_XXX
и r_XXX_blocking. Эти соединение, конечно, должны быть описаны в конфиге.

=cut

use constant DEFAULT_CONNECT => qw[
    cache
    sessions
    csrf
    locks
    sms
    wizard_storage
    fastqueue
    spam_filtering
    files
    referral_programs
    shopcarts
    telegram
];

=item B<redis_config>

    my $config_hashref = redis_config();

Возвращает конфиг Redis из L<SRS::Conf>. Разворачивает его в нужную структуру.

=cut

our $_redis_config_cached;

sub redis_config {
    $_redis_config_cached ||= do {
        my $conf = cfg->get('redis');
        my $indexes = {};

        for my $index_name ( keys %{ $conf->{indexes} } ) {
            my ( $server_name, $index ) = split ':', $conf->{indexes}{$index_name};

            confess "Server name for index '$index_name' undefined" unless $server_name;
            confess "Index number name for index '$index_name' undefined" unless $server_name;

            my $server = $conf->{servers}{$server_name} or confess "Configuration for server '$server_name' not found";

            $indexes->{$index_name} = { index => $index };

            for (qw/port host sock server sentinels service/) {
                $indexes->{$index_name}{$_} = $server->{$_} if exists $server->{$_};
            }
        }

        $indexes;
    };
}

=item B<create_redis_instance>

    create_redis_instance( select => "my_index_name" )

Возвращает соединение, настроенное на конкретное имя клиента и db_index.

Возвращённое соединение нигде не кэшируется, последовательные вызовы этой функции
будут создавать новые соединения.

=cut

sub create_redis_instance {
    my %params = @_;
    my $index_record = redis_config->{$params{select}} // confess "Wrong index name";
    my $index = $index_record->{index};

    if ( $index > 0 ) {
        my $another_on_connect = $params{on_connect};
        $params{on_connect} = sub {
            my ($redis) = @_;
            $redis->select( $index );
            $another_on_connect->( $redis )  if $another_on_connect;
        };
    }

    my $instance = __PACKAGE__->new(%$index_record, %params);

    return $instance;
}

our %_instances = ();

=item B<redis_instance>

    redis_instance( select => "my_index_name" )
    redis_instance( select => "my_index_name", name => 'another' )

Возвращает соединение, настроенное на конкретное имя клиента и db_index.

Для каждого сочетания select/name всегда возвращается один и тот же
экземпляр соединения, так что всегда передавайте уникальный name,
если соединение требуется для подписки pub/sub.

=cut

sub redis_instance {
    my %params = @_;
    my $select = $params{select} // confess "select must be used";
    my $name = $params{name} // '';
    $_instances{"${select}_${name}"} ||= create_redis_instance( %params );
}

=item B<select>

    $redis->select( $db_index );

ВНИМАНИЕ: Этим методом пользоваться не рекомендуется, так как после
реконнекта выбранная БД сбрасывается на 0.

Используйте опцию select в L</redis_instance>, или готовые акцессоры вида r_*,
или формируйте обработчик on_connect при передаче в конструктор.

Этот метод просто наследуется от предка.

=cut

=item B<new>

    my $redis = $class->new( %params );

Дополняет параметры слева через server => L</redis_server_string>.

Автоматически проставляет name для соединения, если его нет.

Далее создает экземпляр класса L<SRS::Comm::Redis>.

=cut

sub new {
    my ( $class, %params ) = @_;
    state $default_name = "SRS:". hostname(). " pid $$";

    $params{name} = $default_name . " " . $params{select} . (defined $params{name} ? " " . $params{name} : '');

    $params{name} =~ s/\s/_/ga;

    my $another_on_connect = $params{on_connect};
    $params{on_connect} = sub {
        my ($redis) = @_;
        {
            local $@; # не портим exception, который может выдать сам Redis
            # на сколько этот трюк документирован? https://groups.google.com/d/msg/redis-db/vZhfTkjus2I/ZYgkivs75AYJ
            while ( !eval{ $redis->exists("srs::comm::redis::specialkey");1 } && $@ =~ /LOADING/ ) { usleep 100_000; }
        }
        $another_on_connect->( $redis )  if $another_on_connect;
    };

    $class->SUPER::new(
        # default params
        encoding      => undef,
        reconnect     => RECONNECT,
        every         => EVERY,
        cnx_timeout   => CNX_TIMEOUT,
        read_timeout  => READ_TIMEOUT,
        write_timeout => WRITE_TIMEOUT,

        $params{sentinels}
            ? ( service => 'mymaster')
            : ( server => $params{sock} || ( ($params{host}||confess "Missing host"). ':'. ($params{port}||confess "Missing port") ) ),

        # config+redis_instance params
        %params,
    );
}

=item B<process> и B<fn_process>

Совмещение проверки ключа с обновлением.

Метод:

    $redis->process( sub { "v" }, "k", 1 );

=cut

sub process {
    my ( $self, $code, $key, $keep_in_seconds ) = @_;

    my $result = $self->get( $key );

    unless (defined $result) {
        $result = $code->();
        $self->set( $key, $result, $keep_in_seconds ? ( 'PX', int($keep_in_seconds * 1000) ) : () );
    }

    return $result;
}

=item B<fn_process>

Функция (подключиться, выберет базу и выполнит метод):

    fn_process( 'cache', sub { "v" }, "k", 1 );

=cut

sub fn_process {
    my ( $select, $code, $key, $keep_in_seconds ) = @_;
    my $redis = eval { redis_instance( select => $select ) };
    if ($@) {
        warn "Redis is not running: ", $@;
        return $code->();
    }
    $redis->process( $code, $key, $keep_in_seconds );
}



=item B<mprocess>

Совмещение проверки кеша с обновлением для нескольких ключей сразу.

Метод:

    my ($v1, $v2) = $redis->mprocess(
        [sub { "v1" }, "k1", 3],
        [sub { "v2" }, "k2", 1],
    );

=cut

sub mprocess {
    my $self = shift;
    # @_ is ([$code1, $key1, $keep_in_seconds1], [$code2, $key2, $keep_in_seconds2], ...)

    my @keys = map { $$_[1] } @_;

    my @values = $self->mget(@keys);

    for my $i (0 .. $#_) {
        unless ( defined $values[$i] ) {
            my ($code, $key, $keep_in_seconds) = @{$_[$i]};
            my $result = $values[$i] = $code->();
            $self->set( $key, $result, $keep_in_seconds ? ( 'PX', int($keep_in_seconds * 1000) ) : ()  );
        }
    }

    return @values;
}

=item B<fn_mprocess>

Функция (подключиться, выберет базу и выполнит метод):

    my ($v1, $v2) = fn_mprocess( 'cache',
        [sub { "v1" }, "k1", 3],
        [sub { "v2" }, "k2", 1],
    );

=cut

sub fn_mprocess {
    my $select = shift;
    my $redis = eval { redis_instance( select => $select ) };
    if ($@) {
        warn "Redis is not running: ", $@;
        return map { $$_[0]->() } @_;
    }
    $redis->mprocess( @_ );
}

=item B<responsive_keys>

То же, что и keys, только если в базе овер 900 млн ключей не блокирует Redis сервер надолго - он остаётся
таким же отзывчивым, как и раньше (чего, правда, нельзя сказать про клиента, т.е. про нас).

Удаляет ключи-дубликаты (могут появляться из-за команды SCAN).

=cut

sub responsive_keys {
    my ($self, $pattern, $block_size) = @_;

    $block_size ||= SCAN_BLOCK_SIZE;

    my $cursor = 0;
    my %result;
    do {
        ($cursor, my $ids) = $self->scan( $cursor, MATCH => $pattern, COUNT => $block_size );
        @result{@$ids}=(); # все ключи будут undef
    } while ($cursor > 0);

    keys %result;
}

=item B<server_time>

Возвращает время на сервере, кэширует дельту на некоторое время.
В следующий раз возвращает время с учётом делты, не обращаясь на сервер.

Может понадобиться чтобы в распределённой системе на разных серверах кластера
получать одинаковое время, с малой погрешностью. Например если один из серверов кластера ставит
время экспирации какой-то записи, а другой будет её удалять, и общее время жизни записи не превышает
нескольких секунд, что может быть сравнимо с отставанием часов между серверами.

Время Redis может отличаться на время пинга. Соответственно оно может чуть-чуть прыгать (такой же эффект
был бы если бы вы брали его каждый раз с редиса, без этой функции).

Эффекты при переводе системного времени туда-сюда на клиенте и на сервере не изучены, так же как и последствия
наступления leap seconds. Целочисленное переполнение не настанет (см. тесты), если время более-менее совпадает.

В скалярном контексте возвращает кол-во целых секунд.

В списковом - (секунды, микросекунды)

Возвращает epoch time, только GMT.

=cut

our $_cached_time_delta;
our $_cached_time_ts;

sub server_time {
    my ($self) = @_;

    my ($local_s, $local_m) = gettimeofday;

    if (!$_cached_time_ts || $local_s > $_cached_time_ts + CACHE_SERVER_DELTA) {
        my ($redis_s, $redis_m) = $self->time;
        confess "Redis server_time called inside redis MULTI transaction" if $redis_s =~ /QUEUED/;
        $_cached_time_delta = ( ( $redis_s - $local_s) * MICROSECONDS_IN_SECOND ) + ($redis_m - $local_m);
        $_cached_time_ts = $local_s;
        return wantarray ? ($redis_s, $redis_m) : $redis_s;
    }
    else {
        $local_m += $_cached_time_delta;
        my $m = $local_m % MICROSECONDS_IN_SECOND;
        my $s = ($local_m - $m) / MICROSECONDS_IN_SECOND;
        return wantarray ? ($local_s + $s, $m) : $local_s + $s;
    }
}

=item B<reconnect>

Выполняет переподсоединение к Redis.

ВАЖНО: работает только с теми соединениями, которые созданы
через B</redis_instance>.

=cut

sub reconnect {
    my ($self) = @_;

    my $found = 0;
    for my $key (keys %_instances) {
        if ( $_instances{$key} == $self ) {
            $_instances{$key} = undef;
            $found = 1;
        }
    }
    die "Cannot reconnect because this instance was not registered through redis_instance."  unless $found;
    eval { $self->quit; }; # нам совсем неинтересны возможные ошибки во время дисконнекта.
}

=item B<unique_key_name>

    unique_key_name( $name )

Returns unique key name based on specified name.

Returns undef on empty name.

Uniqueness based on hostname and pid.

Useful for tests.

=cut

sub unique_key_name {
    my ( $name ) = @_;
    return  unless length $name;

    return "unique:$name:$$/". hostname();
}


our @EXPORT    = ();
our @EXPORT_OK;

# Обязательно push, т.к. первое присваивание происходит в BEGIN (ниже)
push @EXPORT_OK, qw(
    &redis_instance
    &create_redis_instance
    &redis_server_string
    &redis_sentinels_hashref
    &redis_config
    &fn_process
    &fn_mprocess
    &unique_key_name
);

BEGIN {
    my $indexes = redis_config();

    for my $db (DEFAULT_CONNECT) {
        confess "Cannot find index $db in config" unless $indexes->{$db};

        no strict 'refs';
        my ($r_sub, $r_blocking);

        my @blocking_timeouts = (
            read_timeout  => MAX_BLOCKING_SERVER_TIMEOUT() + 20,
            write_timeout => MAX_BLOCKING_SERVER_TIMEOUT() + 20
        );

        my @overrides;
        push @overrides, @blocking_timeouts
            if $db ~~ FORCE_BLOCKING_TIMEOUTS();

        # Создание хэндлов к базам редиса:
        # r_cache
        # r_sessions
        # r_csrf
        # r_locks
        # r_sms
        # r_wizard_storage
        # r_fastqueue
        # r_cache_blocking
        # r_sessions_blocking
        # r_csrf_blocking
        # r_locks_blocking
        # r_sms_blocking
        # r_wizard_storage_blocking
        # r_fastqueue_blocking

        *{__PACKAGE__."::".($r_sub = "r_${db}")} = subname "r_${db}" => sub {
            redis_instance( select => $db, @overrides );
        };

        *{__PACKAGE__."::".($r_blocking = "r_${db}_blocking")} = subname "r_${db}_blocking" => sub {
            redis_instance(
                select => $db,
                name => "${db}__blocking",
                @blocking_timeouts
            );
        };
        use strict 'refs';
        push @EXPORT_OK, $r_sub, $r_blocking;
    }
};

=back

=head1 EXPORTS

* Nothing by default.

* L</redis_instance>, L</redis_server_string>, L</redis_config>,
nonblocking (r_cache) and blocking (r_locks_blocking) handles for each of indexed databases,
L</fn_process>, L</fn_mprocess>.

=cut


1;
